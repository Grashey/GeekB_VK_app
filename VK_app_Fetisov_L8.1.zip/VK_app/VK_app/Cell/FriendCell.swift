//
//  FriendCell.swift
//  VK_app
//
//  Created by Aleksandr Fetisov on 06/07/2019.
//  Copyright © 2019 Aleksandr Fetisov. All rights reserved.
//

import UIKit

class FriendCell: UITableViewCell {

    
    @IBOutlet weak var friendAvatarView: UIImageView!
    @IBOutlet weak var friendNameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        

    }

   

}
