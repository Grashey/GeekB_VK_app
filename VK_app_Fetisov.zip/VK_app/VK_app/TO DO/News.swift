//
//  News.swift
//  VK_app
//
//  Created by Aleksandr Fetisov on 26/07/2019.
//  Copyright © 2019 Aleksandr Fetisov. All rights reserved.
//

import UIKit

struct News {
    let text: String
    let image: UIImage
}
